# Report of Current Strategies executed by Devin McMurrey since August 2021


```python
 
import matplotlib.pyplot as plt 

%matplotlib inline 

import pandas as pd 
import seaborn as sns

import numpy as np


FILE_PATH = "C:\CIL\CSV"
sales_report = open(FILE_PATH + '\sales_report.csv') 
    
df_sales = pd.read_csv(sales_report)

df_sales= pd.DataFrame(df_sales)
#display(df_sales)
x = pd.crosstab(df_sales.Source_of_lead, df_sales.Ultimate_end_Result_)
y = pd.crosstab(df_sales.Source_of_lead, df_sales.Ultimate_end_Result_, margins=True, margins_name = "Total")

display(x)
display(y)

```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Ultimate_end_Result_</th>
      <th>1_meeting</th>
      <th>2_meetings_</th>
      <th>3_meetings_</th>
      <th>4_meetings_</th>
      <th>exchange_correspondence_</th>
      <th>limited_correspondence_</th>
      <th>never_answered_</th>
      <th>not_interested</th>
      <th>open_to_meeting_</th>
    </tr>
    <tr>
      <th>Source_of_lead</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Devin_network</th>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>LinkedIn_Lean_Startup</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Meetup_lean_start_up</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Oranic_Linkedin</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Private_Equity_Firm</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>crunchbase_</th>
      <td>9</td>
      <td>7</td>
      <td>5</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>94</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>facebook_</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>reddit</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Ultimate_end_Result_</th>
      <th>1_meeting</th>
      <th>2_meetings_</th>
      <th>3_meetings_</th>
      <th>4_meetings_</th>
      <th>exchange_correspondence_</th>
      <th>limited_correspondence_</th>
      <th>never_answered_</th>
      <th>not_interested</th>
      <th>open_to_meeting_</th>
      <th>Total</th>
    </tr>
    <tr>
      <th>Source_of_lead</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Devin_network</th>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>LinkedIn_Lean_Startup</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>Meetup_lean_start_up</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>Oranic_Linkedin</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>Private_Equity_Firm</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>0</td>
      <td>1</td>
      <td>10</td>
    </tr>
    <tr>
      <th>crunchbase_</th>
      <td>9</td>
      <td>7</td>
      <td>5</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
      <td>94</td>
      <td>3</td>
      <td>0</td>
      <td>123</td>
    </tr>
    <tr>
      <th>facebook_</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>reddit</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Total</th>
      <td>12</td>
      <td>8</td>
      <td>6</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>115</td>
      <td>3</td>
      <td>1</td>
      <td>154</td>
    </tr>
  </tbody>
</table>
</div>


### above cross tab shows actual count of each prospect and where they were found 


```python
pd.crosstab(df_sales.Source_of_lead, df_sales.Ultimate_end_Result_, margins=True, margins_name = "Total", normalize = True).round(4)*100
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Ultimate_end_Result_</th>
      <th>1_meeting</th>
      <th>2_meetings_</th>
      <th>3_meetings_</th>
      <th>4_meetings_</th>
      <th>exchange_correspondence_</th>
      <th>limited_correspondence_</th>
      <th>never_answered_</th>
      <th>not_interested</th>
      <th>open_to_meeting_</th>
      <th>Total</th>
    </tr>
    <tr>
      <th>Source_of_lead</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Devin_network</th>
      <td>1.95</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>1.3</td>
      <td>0.00</td>
      <td>0.65</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>3.90</td>
    </tr>
    <tr>
      <th>LinkedIn_Lean_Startup</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>1.30</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>1.30</td>
    </tr>
    <tr>
      <th>Meetup_lean_start_up</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.65</td>
      <td>4.55</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>5.19</td>
    </tr>
    <tr>
      <th>Oranic_Linkedin</th>
      <td>0.00</td>
      <td>0.65</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>1.30</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>1.95</td>
    </tr>
    <tr>
      <th>Private_Equity_Firm</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>5.84</td>
      <td>0.00</td>
      <td>0.65</td>
      <td>6.49</td>
    </tr>
    <tr>
      <th>crunchbase_</th>
      <td>5.84</td>
      <td>4.55</td>
      <td>3.25</td>
      <td>0.00</td>
      <td>2.6</td>
      <td>0.65</td>
      <td>61.04</td>
      <td>1.95</td>
      <td>0.00</td>
      <td>79.87</td>
    </tr>
    <tr>
      <th>facebook_</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.65</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.65</td>
    </tr>
    <tr>
      <th>reddit</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.65</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.65</td>
    </tr>
    <tr>
      <th>Total</th>
      <td>7.79</td>
      <td>5.19</td>
      <td>3.90</td>
      <td>0.65</td>
      <td>3.9</td>
      <td>1.30</td>
      <td>74.68</td>
      <td>1.95</td>
      <td>0.65</td>
      <td>100.00</td>
    </tr>
  </tbody>
</table>
</div>



### above cross tab shows actual count of each prospect and where they were found expressed as % of total


```python
pd.crosstab(df_sales.Source_of_lead, df_sales.Ultimate_end_Result_, margins=True, margins_name = "Total", normalize = 'columns').round(4)*100
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Ultimate_end_Result_</th>
      <th>1_meeting</th>
      <th>2_meetings_</th>
      <th>3_meetings_</th>
      <th>4_meetings_</th>
      <th>exchange_correspondence_</th>
      <th>limited_correspondence_</th>
      <th>never_answered_</th>
      <th>not_interested</th>
      <th>open_to_meeting_</th>
      <th>Total</th>
    </tr>
    <tr>
      <th>Source_of_lead</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Devin_network</th>
      <td>25.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>33.33</td>
      <td>0.0</td>
      <td>0.87</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.90</td>
    </tr>
    <tr>
      <th>LinkedIn_Lean_Startup</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>1.74</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.30</td>
    </tr>
    <tr>
      <th>Meetup_lean_start_up</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>50.0</td>
      <td>6.09</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.19</td>
    </tr>
    <tr>
      <th>Oranic_Linkedin</th>
      <td>0.0</td>
      <td>12.5</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>1.74</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.95</td>
    </tr>
    <tr>
      <th>Private_Equity_Firm</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>7.83</td>
      <td>0.0</td>
      <td>100.0</td>
      <td>6.49</td>
    </tr>
    <tr>
      <th>crunchbase_</th>
      <td>75.0</td>
      <td>87.5</td>
      <td>83.33</td>
      <td>0.0</td>
      <td>66.67</td>
      <td>50.0</td>
      <td>81.74</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>79.87</td>
    </tr>
    <tr>
      <th>facebook_</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>100.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.65</td>
    </tr>
    <tr>
      <th>reddit</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>16.67</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.65</td>
    </tr>
  </tbody>
</table>
</div>



## the above cross tab illustrates what percentage of [insert column] was made up of the source. AKA how far in the sales process did we get and where they came from 


```python
pd.crosstab(df_sales.Source_of_lead, df_sales.Ultimate_end_Result_, margins=True, margins_name = "Total", normalize = 'index').round(4)*100
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Ultimate_end_Result_</th>
      <th>1_meeting</th>
      <th>2_meetings_</th>
      <th>3_meetings_</th>
      <th>4_meetings_</th>
      <th>exchange_correspondence_</th>
      <th>limited_correspondence_</th>
      <th>never_answered_</th>
      <th>not_interested</th>
      <th>open_to_meeting_</th>
    </tr>
    <tr>
      <th>Source_of_lead</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Devin_network</th>
      <td>50.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>33.33</td>
      <td>0.00</td>
      <td>16.67</td>
      <td>0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>LinkedIn_Lean_Startup</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>100.00</td>
      <td>0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>Meetup_lean_start_up</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>12.50</td>
      <td>87.50</td>
      <td>0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>Oranic_Linkedin</th>
      <td>0.00</td>
      <td>33.33</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>66.67</td>
      <td>0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>Private_Equity_Firm</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>90.00</td>
      <td>0.00</td>
      <td>10.00</td>
    </tr>
    <tr>
      <th>crunchbase_</th>
      <td>7.32</td>
      <td>5.69</td>
      <td>4.07</td>
      <td>0.00</td>
      <td>3.25</td>
      <td>0.81</td>
      <td>76.42</td>
      <td>2.44</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>facebook_</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>100.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>reddit</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>100.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>Total</th>
      <td>7.79</td>
      <td>5.19</td>
      <td>3.90</td>
      <td>0.65</td>
      <td>3.90</td>
      <td>1.30</td>
      <td>74.68</td>
      <td>1.95</td>
      <td>0.65</td>
    </tr>
  </tbody>
</table>
</div>



## above cross tab illustrates what % each source was made up of each column. AKA what we did with the customers from that source (by row vs by collumn as seen above) 


```python
plt.style.use('seaborn')
bp = x.plot(kind = "bar", stacked = True, rot=0, color=['black', 'red', 'green', 'blue', 'cyan', 'yellow','purple','orange','gold'])
bp.legend(title = "Prospects", bbox_to_anchor=(1, 1.02), loc = 'upper left')
bp.tick_params(axis = 'x', direction= 'out', length = 5, rotation =75, labelsize = 15)
bp.set_xlabel('Source', fontsize=20)
bp.set_ylabel('Total Count', fontsize= 20)
```




    Text(0, 0.5, 'Total Count')




    
![png](output_9_1.png)
    


### The charts above displays my work over the last 9 months (in a crosstabulation & barplot) illustrating where our leads came from and the end result of contact with them.  My efforts so far on crunchbase reachouts have seen to 122 total individuals being contacted. Of these 122 individuals 93 never responded creating a successfull contact rate to correspondence and meetings of 23.77%. As this has been the major focus so far for meeting prospects it is no surprise almost all of our meetings came from these leads. From the 29 contacts, we had a total of 38 meetings; which resulted in zero sales and no responses to my follow up contact attemps since the final meeting. (basically it would have been a more efficient use of our time had we not had the meeting at all) 
 


### Our two most impactful leads came from facebook and reddit. Which of course are Tradelines and Pigeon Loans. While we should not consider Pigeon Loans a success from an ROI (it was the contact with the most time invested by far) it has been by far our strongest relationship since this process began aside from Tradelines. The one sale made out of this process came from facebook, which can only be chalked up to pure luck as I just happen to be a part of the group Dude posted in, and I happened to be on Facebook right when he posted it. I feel this data calls into qustion the effectiveness in the current strategy. It is cumbersome, takes a tremendous amount of time/effort to reach out and qualify 1 individual, and can in no way be automated to correct this ineffeciency. All of the previous points are exaserbated 2-3x by the lean startup-meetup strategy. The main problems arising from the current strategy are a lack of clarity of goals in the initial sit down, misjudging the prospects finacial capabilities, and/or MOST IMPORTANTLY a lack of interest on the prospects side for unsolicited advice. 

### In a few instances, through my own personal network we had succesfull meetings where we were asked for data and testimonials to back up our declarations. These resources were never provided so the potential partnership was never even given an opportunity to begin. In one intance we offered to link one of my network connections with a referral, which never actually occured and now he wont answer me at all. This ultimately culminates and reveals that of the connections we have made this year, none have been from crunchbase. Furthermore, we are potentially losing out on real partnerships and a strong referall network by lacking both qualitative and more importantly quantitative data to back up our promises of delivered value.

## Given these outcomes I would suggest a pivot to focus more on other areas of sourcing. Especially one group in particualr: P/E firms. 

## My reccomendation is based on the following logic: 

## 1. We have a similar method like crunchbase from which to pull these sources

## 2. The above process could be automated by a web scraper/parser that we can load each site into and pull contact information quickly 

## 3. We can send a terse, direct email to these prosects that can more or less be exactly the same (automated) to each of the contacts we pull
##  Ex: Hi [name], I represent a Venture Studio based in Chicago. We specialize in digital product innovation.  Experience has demonstrated our clients with major P/E stake are looking for the kind of development work we provide, and I saw our firms' share a similar focus when partnering. Hoping to connect and leverage networks.

## 4. So far I have reached out to 154 people over the last 9 months. 10 of the 154 were from P/E firms. I was able to reach out to all 10 in one day within a 3-4 hour period. Meaning I could feasibly reach out to more than 2x the total numer of current people prospected (9 months) within a 2 month period, even with zero automation.  

## 5. These people will only take a meeting when they are willing to consider our offer, and I can effectively target members of their business development team or senior associates (who are hungry for promotion to partner). Furthermore our script sets up clearly the goals and parameters for the first meeting. Creating a more organized agenda and process which will culminate in a more professional and structured approach. 

## 6. When we do get a yes, we will get more than just one sale, it will set up a partneship for cohesion and synergy with future business endeavors. 

## 7. When they refer us to someone with whom they have just invested a tremendous amount of capital we will know for certain the prospect will be able to afford us. Furthermore, the referral will immensely strengthen our closing ratio by eleminating the bloat from wasted meetings that do not evolve into anything. 

## 8. It can't possibly be any less successful than the crunchbase strategy and we will know quickly (within 2-3 months) if this will work as the process is more rapid and iterable. 

## 9. This could eventually be expanded out to VC firms and Accelerator/incubators 
    


